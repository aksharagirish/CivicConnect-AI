import { Issue } from '../types';

export const defaultIssues: Issue[] = [
  {
    id: "civic-1",
    title: "Deep Double Pothole on Right Lane",
    description: "Two major, deep potholes on the right lane of Elm Creek Blvd. Cars are swerving dangerously into the next lane to avoid them, risking side collisions during rush hour.",
    category: "Pothole",
    location: {
      lat: 45.0982,
      lng: -93.3912,
      address: "8405 Elm Creek Blvd, Maple Grove, MN 55369"
    },
    status: "Pending",
    severity: "High",
    estimatedImpact: "Causes sudden traffic slowdowns and swerving, risking tyre blowouts and multi-vehicle crashes.",
    recommendedAction: "Apply a rapid-set asphalt patch and set up warning cones immediately prior to permanent resurfacing.",
    imageUrl: "https://images.unsplash.com/photo-1515162305285-0293e4767cc2?auto=format&fit=crop&w=600&q=80",
    votes: 34,
    votedUsers: ["user-2", "user-3"],
    verifications: 12,
    verifiedUsers: ["user-1"],
    createdAt: "2026-06-21T10:30:00Z",
    updatedAt: "2026-06-21T10:30:00Z",
    history: [
      {
        status: "Pending",
        updatedAt: "2026-06-21T10:30:00Z",
        comment: "Issue reported by community member. Awaiting dispatch."
      }
    ],
    aiGenerated: true,
    reporterName: "Marcus Vance",
    reporterEmail: "marcus.vance@netcivic.org"
  },
  {
    id: "civic-2",
    title: "Active Main Water Leak Under Sidewalk",
    description: "Water is continuously bubbling up from under the concrete sidewalk slab, creating a miniature stream in the gutter. It is flooding the adjacent lawn and threatening to erode the walkway foundation.",
    category: "Water Leak",
    location: {
      lat: 45.0924,
      lng: -93.3856,
      address: "9312 Arbor Lakes Pkwy, Maple Grove, MN 55369"
    },
    status: "In Progress",
    severity: "Critical",
    estimatedImpact: "Sub-surface soil erosion under the sidewalk could lead to sinkholes or concrete collapse. Significant clean water wastage.",
    recommendedAction: "Dispatch public works water main department, shut off valve, excavate sidewalk slab, and replace ruptured main pipe.",
    imageUrl: "https://images.unsplash.com/photo-1542013936693-8848e57412ff?auto=format&fit=crop&w=600&q=80",
    votes: 56,
    votedUsers: ["user-1"],
    verifications: 28,
    verifiedUsers: ["user-2"],
    createdAt: "2026-06-20T08:15:00Z",
    updatedAt: "2026-06-22T14:20:00Z",
    history: [
      {
        status: "Pending",
        updatedAt: "2026-06-20T08:15:00Z",
        comment: "Water leak reported by Maple Grove resident."
      },
      {
        status: "In Progress",
        updatedAt: "2026-06-22T14:20:00Z",
        comment: "Maple Grove Utilities is on-site. Main water valve throttled, excavation team scheduled for repair."
      }
    ],
    aiGenerated: true,
    reporterName: "Elena Rostova",
    reporterEmail: "elena.ro@gmail.com"
  },
  {
    id: "civic-3",
    title: "Completely Dark Streetlight Near School Crossing",
    description: "The primary overhead mercury vapor streetlight directly overlooking the pedestrian crosswalk has been dead for 4 nights. The area is pitch black, making school kids returning from evening sports invisible to turning cars.",
    category: "Streetlight",
    location: {
      lat: 45.1051,
      lng: -93.3985,
      address: "11200 93rd Ave N, Maple Grove, MN 55369"
    },
    status: "Resolved",
    severity: "High",
    estimatedImpact: "Extreme danger to school children, pedestrians, and cyclists after dark. High risk of pedestrian-car collision.",
    recommendedAction: "Replace burnt-out LED driver or shorted photo-control node. Verify voltage at the mast arm.",
    imageUrl: "https://images.unsplash.com/photo-1509021436665-8f37bc7065be?auto=format&fit=crop&w=600&q=80",
    votes: 42,
    votedUsers: [],
    verifications: 15,
    verifiedUsers: [],
    createdAt: "2026-06-18T21:40:00Z",
    updatedAt: "2026-06-22T09:00:00Z",
    history: [
      {
        status: "Pending",
        updatedAt: "2026-06-18T21:40:00Z",
        comment: "Dead light reported next to elementary school crosswalk."
      },
      {
        status: "In Progress",
        updatedAt: "2026-06-20T11:10:00Z",
        comment: "Crew assigned to streetlight sector 4. Bulb / sensor replacement planned."
      },
      {
        status: "Resolved",
        updatedAt: "2026-06-22T09:00:00Z",
        comment: "Photo-sensor node replaced and fixture converted to modern high-efficiency 90W LED. Fully operational."
      }
    ],
    aiGenerated: true,
    reporterName: "Dave Miller",
    reporterEmail: "dave.miller@schoolboard.org"
  },
  {
    id: "civic-4",
    title: "Illegal Waste Dumping in Forest Reserve Buffer",
    description: "Someone dumped multiple mattresses, old furniture, several car batteries, and bags of domestic construction tiles in the preservation wooded strip directly next to the community creek trail. Acid leaks from batteries are a risk.",
    category: "Waste Dumping",
    location: {
      lat: 45.1011,
      lng: -93.3802,
      address: "Weaver Lake Road Woodland Trail, Maple Grove, MN 55311"
    },
    status: "Pending",
    severity: "High",
    estimatedImpact: "Contamination of the local creek water via battery lead-acid run-off, severe aesthetic blight, and encouragement of further dumping.",
    recommendedAction: "Schedule specialized environmental waste hazard crew to salvage car batteries, clean debris, and install surveillance camera warning sign.",
    imageUrl: "https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&w=600&q=80",
    votes: 21,
    votedUsers: [],
    verifications: 8,
    verifiedUsers: [],
    createdAt: "2026-06-22T12:00:00Z",
    updatedAt: "2026-06-22T13:00:00Z",
    history: [
      {
        status: "Pending",
        updatedAt: "2026-06-22T12:00:00Z",
        comment: "Dumping spotted on morning jog. Constructed environmental hazard case."
      }
    ],
    aiGenerated: true,
    reporterName: "Sarah Connor",
    reporterEmail: "sconnor@woodslovers.org"
  }
];
