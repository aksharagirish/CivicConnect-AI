import React from "react";
import { ShieldCheck, Flame, Vote, Sparkles, CheckCircle2, RefreshCw } from "lucide-react";
import { motion } from "motion/react";
import { Issue } from "../types";

interface MetricsProps {
  issues: Issue[];
}

export default function Metrics({ issues }: MetricsProps) {
  const stats = React.useMemo(() => {
    const total = issues.length;
    const pending = issues.filter((i) => i.status === "Pending").length;
    const progress = issues.filter((i) => i.status === "In Progress").length;
    const resolved = issues.filter((i) => i.status === "Resolved").length;
    const votes = issues.reduce((acc, i) => acc + i.votes, 0);
    const vers = issues.reduce((acc, i) => acc + i.verifications, 0);
    const aiCases = issues.filter((i) => i.aiGenerated).length;

    const resolutionRate = total > 0 ? Math.round((resolved / total) * 100) : 0;
    const aiAccuracyRatio = aiCases > 0 ? Math.round((issues.filter(i => i.aiGenerated && i.status !== "Pending").length / aiCases) * 100) : 88;

    return {
      total,
      pending,
      progress,
      resolved,
      votes,
      vers,
      resolutionRate,
      aiAccuracyRatio,
      aiCases
    };
  }, [issues]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {/* Total Reported Bento Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 relative overflow-hidden backdrop-blur-md flex flex-col justify-between">
        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full filter blur-2xl pointer-events-none" />
        <div className="flex justify-between items-start">
          <div>
            <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">Incident Registry</p>
            <h3 className="text-2xl font-bold text-slate-100 mt-1">{stats.total}</h3>
          </div>
          <div className="w-8 h-8 bg-emerald-950 text-emerald-400 border border-emerald-500/20 rounded-xl flex items-center justify-center">
            <RefreshCw className="w-4 h-4 animate-spin-slow" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1.5 text-xs text-emerald-400/90 font-mono">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          {stats.pending + stats.progress} actively monitored cases
        </div>
      </div>

      {/* Resolution Rate Bento Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 relative overflow-hidden backdrop-blur-md flex flex-col justify-between">
        <div className="absolute top-0 right-0 w-32 h-32 bg-sky-500/5 rounded-full filter blur-2xl pointer-events-none" />
        <div className="flex justify-between items-start">
          <div>
            <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">Resolution Efficiency</p>
            <h3 className="text-2xl font-bold text-slate-100 mt-1">{stats.resolutionRate}%</h3>
          </div>
          <div className="w-8 h-8 bg-sky-950 text-sky-400 border border-sky-500/20 rounded-xl flex items-center justify-center">
            <CheckCircle2 className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-4">
          <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-800">
            <div
              className="bg-sky-400 h-full rounded-full transition-all duration-550"
              style={{ width: `${stats.resolutionRate}%` }}
            />
          </div>
          <p className="text-[9px] font-mono text-slate-500 mt-1">{stats.resolved} of {stats.total} public hazards solved</p>
        </div>
      </div>

      {/* Community Engagement Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 relative overflow-hidden backdrop-blur-md flex flex-col justify-between">
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full filter blur-2xl pointer-events-none" />
        <div className="flex justify-between items-start">
          <div>
            <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">Community Verification</p>
            <h3 className="text-2xl font-bold text-slate-100 mt-1">{stats.votes + stats.vers}</h3>
          </div>
          <div className="w-8 h-8 bg-amber-950 text-amber-400 border border-amber-500/25 rounded-xl flex items-center justify-center">
            <Vote className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-4 flex flex-wrap justify-between gap-1 text-[9px] font-mono text-slate-500">
          <span>Upvotes: <strong className="text-slate-350">{stats.votes}</strong></span>
          <span className="w-1.5 h-1.5 rounded-full bg-slate-800 mt-1" />
          <span>Verifications: <strong className="text-slate-350">{stats.vers}</strong></span>
        </div>
      </div>

      {/* Gemini AI Powered Metric */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 relative overflow-hidden backdrop-blur-md flex flex-col justify-between">
        <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/5 rounded-full filter blur-2xl pointer-events-none" />
        <div className="flex justify-between items-start">
          <div>
            <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">AI Categorization</p>
            <h3 className="text-2xl font-bold text-slate-100 mt-1">{stats.aiCases} Cases</h3>
          </div>
          <div className="w-8 h-8 bg-purple-950 text-purple-400 border border-purple-500/20 rounded-xl flex items-center justify-center">
            <Sparkles className="w-4 h-4 animate-pulse" />
          </div>
        </div>
        <div className="mt-4 text-xs text-purple-400/90 font-mono flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
          <span>{stats.aiAccuracyRatio}% system precision</span>
        </div>
      </div>
    </div>
  );
}
