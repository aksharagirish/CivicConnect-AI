import React, { useState, useMemo, useRef, useEffect } from "react";
import { MapPin, Compass, ShieldAlert, CheckCircle, Clock, Trash2, Lightbulb, Droplets, Grid, Eye, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Issue, IssueCategory, IssueStatus } from "../types";

interface MapContainerProps {
  issues: Issue[];
  selectedIssueId: string | null;
  onSelectIssue: (id: string | null) => void;
  reportingLocation: { lat: number; lng: number; address: string } | null;
  onSelectReportingLocation: (location: { lat: number; lng: number; address: string }) => void;
  isReportingMode: boolean;
}

// Bounding box for Maple Grove coordinates
const MIN_LAT = 45.090;
const MAX_LAT = 45.110;
const MIN_LNG = -93.405;
const MAX_LNG = -93.375;

export default function MapContainer({
  issues,
  selectedIssueId,
  onSelectIssue,
  reportingLocation,
  onSelectReportingLocation,
  isReportingMode
}: MapContainerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ width: 600, height: 450 });
  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  // Update dimensions with ResizeObserver to prevent rigid constraints
  useEffect(() => {
    if (!containerRef.current) return;
    const resizeObserver = new ResizeObserver((entries) => {
      for (let entry of entries) {
        const { width, height } = entry.contentRect;
        setDimensions({ width: width || 600, height: height || 450 });
      }
    });
    resizeObserver.observe(containerRef.current);
    return () => resizeObserver.disconnect();
  }, []);

  // Map latitude and longitude to X, Y percentages
  const getCoordinates = (lat: number, lng: number) => {
    const latInBounds = Math.max(MIN_LAT, Math.min(MAX_LAT, lat));
    const lngInBounds = Math.max(MIN_LNG, Math.min(MAX_LNG, lng));

    const pctX = (lngInBounds - MIN_LNG) / (MAX_LNG - MIN_LNG);
    const pctY = 1 - (latInBounds - MIN_LAT) / (MAX_LAT - MIN_LAT); // higher lat is up, lower Y is down

    return {
      x: pctX * dimensions.width,
      y: pctY * dimensions.height
    };
  };

  // Map grid mouse coordinates back to Maple Grove GPS coordinates
  const getGPSCoords = (x: number, y: number) => {
    const pctX = x / dimensions.width;
    const pctY = 1 - (y / dimensions.height);

    const lat = MIN_LAT + pctY * (MAX_LAT - MIN_LAT);
    const lng = MIN_LNG + pctX * (MAX_LNG - MIN_LNG);

    // Approximate address based on nearest quarter sector
    let sector = "Subsector Alpha";
    if (lat > 45.10 && lng > -93.39) sector = "North Arbor Lakes Sector";
    else if (lat > 45.10 && lng <= -93.39) sector = "Elm Creek Reserve Sector";
    else if (lat <= 45.10 && lng > -93.39) sector = "East Town Transit Corridor";
    else sector = "Weaver Lake Residential Zone";

    const localAddr = `${Math.floor(8000 + pctX * 3000)} ${pctY > 0.5 ? "Elm Creek Parkway" : "Arbor Lakes Dr"}, Maple Grove, MN`;

    return {
      lat: parseFloat(lat.toFixed(6)),
      lng: parseFloat(lng.toFixed(6)),
      address: `${localAddr} [${sector}]`
    };
  };

  const handleMapClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (isDragging) return;

    const svg = e.currentTarget;
    const rect = svg.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * dimensions.width;
    const y = ((e.clientY - rect.top) / rect.height) * dimensions.height;

    if (isReportingMode) {
      const location = getGPSCoords(x, y);
      onSelectReportingLocation(location);
    } else {
      // Clear selected issue on blank space click
      onSelectIssue(null);
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (isReportingMode) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX - offset.x, y: e.clientY - offset.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setOffset({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const selectedIssue = useMemo(() => {
    return issues.find((i) => i.id === selectedIssueId) || null;
  }, [issues, selectedIssueId]);

  // Visual cues for categories
  const getCategoryTheme = (category: IssueCategory) => {
    switch (category) {
      case "Pothole":
        return { color: "text-amber-500 bg-amber-500", icon: ShieldAlert, fill: "#F59E0B" };
      case "Water Leak":
        return { color: "text-sky-500 bg-sky-500", icon: Droplets, fill: "#0EA5E9" };
      case "Streetlight":
        return { color: "text-yellow-400 bg-yellow-400", icon: Lightbulb, fill: "#FACC15" };
      case "Waste Dumping":
        return { color: "text-emerald-500 bg-emerald-500", icon: Trash2, fill: "#10B981" };
      case "Public Infrastructure":
        return { color: "text-purple-500 bg-purple-500", icon: Grid, fill: "#A855F7" };
      default:
        return { color: "text-slate-400 bg-slate-400", icon: AlertCircle, fill: "#94A3B8" };
    }
  };

  return (
    <div className="flex flex-col bg-slate-900/40 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl h-full backdrop-blur-md">
      {/* Map Control Bar */}
      <div className="flex justify-between items-center px-6 py-4 bg-slate-900 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <Compass className="w-5 h-5 text-emerald-400 animate-spin-slow" />
          <div>
            <h3 className="font-semibold text-slate-100 text-sm">Hyperlocal Vector Center</h3>
            <p className="text-xs text-slate-500">Maple Grove Municipal Grid (93.39° W, 45.10° N)</p>
          </div>
        </div>
        <div className="flex gap-2">
          {isReportingMode ? (
            <div className="text-xs px-3 py-1.5 bg-emerald-950/85 text-emerald-400 rounded-full border border-emerald-500/30 flex items-center gap-2 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Click Map to Place Issue Pin
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => { setZoom(1); setOffset({ x: 0, y: 0 }); }}
                className="text-xs text-slate-400 hover:text-slate-200 px-2 py-1 border border-slate-800 rounded-md bg-slate-950"
              >
                Reset Map
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Map Render Workspace */}
      <div
        ref={containerRef}
        className="relative flex-1 bg-[#0c1322] cursor-crosshair overflow-hidden select-none min-h-[380px]"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {/* Dynamic Stylized Background Vector Grid */}
        <svg
          onClick={handleMapClick}
          className="absolute inset-0 w-full h-full"
          viewBox={`0 0 ${dimensions.width} ${dimensions.height}`}
          xmlns="http://www.w3.org/2000/svg"
        >
          <g transform={`translate(${offset.x}, ${offset.y}) scale(${zoom})`}>
            {/* Soft grid lines */}
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(51, 65, 85, 0.2)" strokeWidth="1" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />

            {/* Geographical Zones (Maple Grove landmarks) */}
            {/* Elm Creek Park Reserve Forest on Top/Left */}
            <path
              d={`M 10 10 Q 150 15, 180 80 T 120 180 Q 30 190, 20 120 Z`}
              fill="rgba(16, 185, 129, 0.08)"
              stroke="rgba(16, 185, 129, 0.2)"
              strokeWidth="1.5"
            />
            <text x="50" y="80" fill="rgba(16, 185, 129, 0.5)" className="text-[10px] font-mono tracking-widest font-bold select-none">
              ELM CREEK FOREST
            </text>

            {/* Shingle River Canal winding right across lower part */}
            <path
              d={`M -50 ${dimensions.height * 0.7} Q ${dimensions.width * 0.3} ${dimensions.height * 0.55}, ${dimensions.width * 0.6} ${dimensions.height * 0.8} T ${dimensions.width + 50} ${dimensions.height * 0.75}`}
              fill="none"
              stroke="rgba(14, 165, 233, 0.18)"
              strokeWidth="14"
              strokeLinecap="round"
            />
            <path
              d={`M -50 ${dimensions.height * 0.7} Q ${dimensions.width * 0.3} ${dimensions.height * 0.55}, ${dimensions.width * 0.6} ${dimensions.height * 0.8} T ${dimensions.width + 50} ${dimensions.height * 0.75}`}
              fill="none"
              stroke="rgba(14, 165, 233, 0.3)"
              strokeWidth="3"
              strokeDasharray="4 8"
              strokeLinecap="round"
            />
            <text x={dimensions.width * 0.7} y={dimensions.height * 0.7} fill="rgba(14, 165, 233, 0.4)" className="text-[9px] font-mono select-none" transform="rotate(3, 400, 300)">
              SHINGLE WATERWAY
            </text>

            {/* Major Arteries - Main Street & Highway Grid */}
            {/* Arbor Lakes Highway - diagonal */}
            <line
              x1="-20" y1={dimensions.height * 0.4}
              x2={dimensions.width + 20} y2={dimensions.height * 0.4}
              stroke="rgba(71, 85, 105, 0.35)"
              strokeWidth="8"
            />
            <line
              x1="-20" y1={dimensions.height * 0.4}
              x2={dimensions.width + 20} y2={dimensions.height * 0.4}
              stroke="rgba(245, 158, 11, 0.2)"
              strokeWidth="1"
              strokeDasharray="5 5"
            />
            <text x="20" y={dimensions.height * 0.4 - 8} fill="rgba(148, 163, 184, 0.5)" className="text-[9px] font-mono font-bold select-none">
              ARBOR LAKES HWY (SECTOR 4)
            </text>

            {/* Weaver Lake Road - Vertical intersection */}
            <line
              x1={dimensions.width * 0.45} y1="-10"
              x2={dimensions.width * 0.45} y2={dimensions.height + 10}
              stroke="rgba(71, 85, 105, 0.35)"
              strokeWidth="8"
            />
            <line
              x1={dimensions.width * 0.45} y1="-10"
              x2={dimensions.width * 0.45} y2={dimensions.height + 10}
              stroke="rgba(245, 158, 11, 0.15)"
              strokeWidth="1.5"
              strokeDasharray="4 4"
            />
            <text x={dimensions.width * 0.45 + 10} y="40" fill="rgba(148, 163, 184, 0.5)" className="text-[9px] font-mono font-bold select-none" transform={`rotate(90, ${dimensions.width * 0.45 + 10}, 40)`}>
              WEAVER LAKE RD
            </text>

            {/* Community Sector Crossings */}
            <circle cx={dimensions.width * 0.45} cy={dimensions.height * 0.4} r="15" fill="none" stroke="rgba(245, 158, 11, 0.3)" strokeWidth="1.5" />
            <circle cx={dimensions.width * 0.45} cy={dimensions.height * 0.4} r="25" fill="none" stroke="rgba(245, 158, 11, 0.1)" strokeWidth="1" strokeDasharray="3 3" />

            {/* Render Current Active Pins */}
            {issues.map((issue) => {
              const coords = getCoordinates(issue.location.lat, issue.location.lng);
              const theme = getCategoryTheme(issue.category);
              const CategoryIcon = theme.icon;
              const isSelected = issue.id === selectedIssueId;
              const isResolved = issue.status === "Resolved";
              const isInProgress = issue.status === "In Progress";

              return (
                <g key={issue.id} className="cursor-pointer">
                  {/* Outer Radar Glow for selected issues */}
                  {isSelected && (
                    <circle
                      cx={coords.x}
                      cy={coords.y}
                      r="22"
                      fill="none"
                      stroke={isResolved ? "#10B981" : isInProgress ? "#0EA5E9" : "#F59E0B"}
                      strokeWidth="2"
                    >
                      <animate attributeName="r" values="10;28;10" dur="2s" repeatCount="indefinite" />
                      <animate attributeName="opacity" values="0.8;0;0.8" dur="2s" repeatCount="indefinite" />
                    </circle>
                  )}

                  {/* Pulsing beacon behind critical status */}
                  {issue.severity === "Critical" && !isResolved && (
                    <circle
                      cx={coords.x}
                      cy={coords.y}
                      r="16"
                      fill="none"
                      stroke="#EF4444"
                      strokeWidth="1.5"
                    >
                      <animate attributeName="r" values="6;20;6" dur="1.5s" repeatCount="indefinite" />
                      <animate attributeName="opacity" values="1;0;1" dur="1.5s" repeatCount="indefinite" />
                    </circle>
                  )}

                  {/* Pin Circle SVG Container */}
                  <g
                    transform={`translate(${coords.x - 14}, ${coords.y - 14})`}
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectIssue(issue.id);
                    }}
                  >
                    {/* Shadow Blob */}
                    <circle cx="14" cy="24" r="6" fill="rgba(2, 6, 23, 0.7)" filter="blur(1px)" />

                    {/* Outer Circle Container */}
                    <rect
                      x="2"
                      y="2"
                      width="24"
                      height="24"
                      rx="12"
                      fill={
                        isResolved
                          ? "#064E3B"
                          : isSelected
                          ? "#0F172A"
                          : "#1E293B"
                      }
                      stroke={
                        isResolved
                          ? "#10B981"
                          : isSelected
                          ? "#38BDF8"
                          : issue.severity === "Critical"
                          ? "#EF4444"
                          : theme.fill
                      }
                      strokeWidth={isSelected ? "2.5" : "1.5"}
                    />

                    {/* Small category icon inside */}
                    <g transform="translate(6, 6) scale(0.65)">
                      <CategoryIcon
                        className={
                          isResolved
                            ? "text-emerald-400"
                            : issue.severity === "Critical"
                            ? "text-red-500 animate-pulse"
                            : theme.color
                        }
                      />
                    </g>

                    {/* Mini Status Dot */}
                    <circle
                      cx="23"
                      cy="5"
                      r="3.5"
                      fill={
                        isResolved
                          ? "#10B981"
                          : isInProgress
                          ? "#0EA5E9"
                          : "#F59E0B"
                      }
                      stroke="#0F172A"
                      strokeWidth="1"
                    />
                  </g>
                </g>
              );
            })}

            {/* active placement reporting pin */}
            {isReportingMode && reportingLocation && (
              <g>
                const reportCoords = getCoordinates(reportingLocation.lat, reportingLocation.lng);
                <g transform={`translate(${getCoordinates(reportingLocation.lat, reportingLocation.lng).x - 16}, ${getCoordinates(reportingLocation.lat, reportingLocation.lng).y - 32})`}>
                  {/* Bouncing effect for dropping */}
                  <path
                    d="M16 0C7.16 0 0 7.16 0 16c0 11.25 14.25 24.38 14.88 24.94a1.71 1.71 0 0 0 2.25 0C17.75 40.38 32 27.25 32 16 32 7.16 24.84 0 16 0zm0 10a6 6 0 1 1-6 6 6 6 0 0 1 6-6z"
                    fill="#34D399"
                    stroke="#022C22"
                    strokeWidth="1.5"
                  />
                  <circle cx="16" cy="16" r="4" fill="#022C22" />
                </g>
                <circle
                  cx={getCoordinates(reportingLocation.lat, reportingLocation.lng).x}
                  cy={getCoordinates(reportingLocation.lat, reportingLocation.lng).y}
                  r="6"
                  fill="none"
                  stroke="#34D399"
                  strokeWidth="2"
                >
                  <animate attributeName="r" values="3;12;3" dur="1s" repeatCount="indefinite" />
                </circle>
              </g>
            )}
          </g>
        </svg>

        {/* Selected Issue Floating Panel Overlay */}
        <AnimatePresence>
          {selectedIssue && (
            <motion.div
              initial={{ opacity: 0, y: 15, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 15, scale: 0.95 }}
              className="absolute bottom-4 left-4 right-4 bg-slate-950/95 border border-slate-800 p-4 rounded-2xl shadow-2xl flex flex-col md:flex-row gap-4 items-start md:items-center justify-between backdrop-blur-md"
            >
              <div className="flex gap-4 items-center flex-1">
                {selectedIssue.imageUrl ? (
                  <img
                    src={selectedIssue.imageUrl}
                    alt={selectedIssue.title}
                    className="w-16 h-16 rounded-xl object-cover border border-slate-800 shrink-0"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-xl bg-slate-900 border border-slate-800 shrink-0 flex items-center justify-center text-slate-500 font-mono text-xs">
                    No Img
                  </div>
                )}
                <div>
                  <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full select-none flex items-center gap-1 font-bold ${
                      selectedIssue.status === "Resolved"
                        ? "bg-emerald-950/60 text-emerald-400 border border-emerald-500/20"
                        : selectedIssue.status === "In Progress"
                        ? "bg-sky-950/60 text-sky-400 border border-sky-500/20"
                        : "bg-amber-950/60 text-amber-400 border border-amber-500/20"
                    }`}>
                      {selectedIssue.status === "Resolved" && <CheckCircle className="w-3 h-3" />}
                      {selectedIssue.status === "In Progress" && <Clock className="w-3 h-3" />}
                      {selectedIssue.status === "Pending" && <ShieldAlert className="w-3 h-3" />}
                      {selectedIssue.status}
                    </span>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold uppercase ${
                      selectedIssue.severity === "Critical"
                        ? "bg-rose-950 text-rose-400 border border-rose-500/30"
                        : selectedIssue.severity === "High"
                        ? "bg-orange-950 text-orange-400 border border-orange-500/30"
                        : "bg-slate-900 text-slate-400 border border-slate-800"
                    }`}>
                      {selectedIssue.severity}
                    </span>
                    <span className="text-[10px] font-mono bg-slate-900 text-slate-400 px-2.5 py-0.5 rounded-full border border-slate-800">
                      {selectedIssue.category}
                    </span>
                  </div>
                  <h4 className="font-bold text-slate-100 text-sm leading-tight line-clamp-1">{selectedIssue.title}</h4>
                  <p className="text-slate-400 text-xs mt-1 leading-normal line-clamp-1 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-emerald-400" />
                    {selectedIssue.location.address}
                  </p>
                </div>
              </div>
              <div className="flex gap-2 w-full md:w-auto shrink-0 border-t border-slate-900 md:border-t-0 pt-3 md:pt-0">
                <button
                  onClick={() => onSelectIssue(selectedIssue.id)}
                  className="flex-1 md:flex-initial text-xs text-slate-200 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 px-3.5 py-2 rounded-xl transition font-medium flex items-center justify-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5 text-sky-400" />
                  View Incident Hub
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Small floating compass compass */}
        <div className="absolute right-4 top-4 bg-slate-950/80 border border-slate-800 p-2.5 rounded-xl flex items-center gap-2 pointer-events-none shadow-xl">
          <Compass className="w-4 h-4 text-emerald-400 animate-pulse" />
          <span className="text-[10px] font-mono text-slate-400 tracking-wider">MAPLE GROVE</span>
        </div>
      </div>
    </div>
  );
}
