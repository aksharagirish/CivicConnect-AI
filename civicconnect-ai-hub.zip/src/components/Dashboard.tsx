import React, { useState, useMemo } from "react";
import { Search, MapPin, CheckCircle, Clock, ShieldAlert, Vote, ShieldCheck, Sparkles, Filter, ChevronRight, User, Calendar, PlusCircle, AlertTriangle, X, Image as ImageIcon, Wrench } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Issue, IssueCategory, IssueStatus, IssueSeverity } from "../types";

interface DashboardProps {
  issues: Issue[];
  selectedIssueId: string | null;
  onSelectIssue: (id: string | null) => void;
  onVoteIssue: (id: string) => Promise<void>;
  onVerifyIssue: (id: string) => Promise<void>;
  onUpdateStatus: (id: string, status: IssueStatus, comment: string) => Promise<void>;
  currentUserId: string;
}

const CATEGORY_FILTERS: (IssueCategory | "All")[] = ["All", "Pothole", "Water Leak", "Streetlight", "Waste Dumping", "Public Infrastructure", "Other"];
const STATUS_FILTERS: (IssueStatus | "All")[] = ["All", "Pending", "In Progress", "Resolved"];

export default function Dashboard({
  issues,
  selectedIssueId,
  onSelectIssue,
  onVoteIssue,
  onVerifyIssue,
  onUpdateStatus,
  currentUserId
}: DashboardProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<IssueCategory | "All">("All");
  const [selectedStatus, setSelectedStatus] = useState<IssueStatus | "All">("All");

  // Admin logger simulation state
  const [adminComment, setAdminComment] = useState("");
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);
  const [isUpdatingState, setIsUpdatingState] = useState(false);

  // Filter issues based on search, category selection, and status selection
  const filteredIssues = useMemo(() => {
    return issues.filter((issue) => {
      const matchesSearch =
        issue.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        issue.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        issue.location.address.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === "All" || issue.category === selectedCategory;
      const matchesStatus = selectedStatus === "All" || issue.status === selectedStatus;
      return matchesSearch && matchesCategory && matchesStatus;
    });
  }, [issues, searchTerm, selectedCategory, selectedStatus]);

  const selectedIssue = useMemo(() => {
    return issues.find((i) => i.id === selectedIssueId) || null;
  }, [issues, selectedIssueId]);

  const getStatusIcon = (status: IssueStatus) => {
    switch (status) {
      case "Resolved":
        return <CheckCircle className="w-4 h-4 text-emerald-400" />;
      case "In Progress":
        return <Clock className="w-4 h-4 text-sky-400" />;
      default:
        return <ShieldAlert className="w-4 h-4 text-amber-500" />;
    }
  };

  const getStatusStyles = (status: IssueStatus) => {
    switch (status) {
      case "Resolved":
        return "bg-emerald-950/40 text-emerald-400 border border-emerald-500/20";
      case "In Progress":
        return "bg-sky-950/40 text-sky-400 border border-sky-500/20";
      default:
        return "bg-amber-950/40 text-amber-400 border border-amber-500/20";
    }
  };

  const getSeverityStyle = (sev: IssueSeverity) => {
    switch (sev) {
      case "Critical":
        return "bg-rose-950/80 text-rose-400 border border-rose-500/30";
      case "High":
        return "bg-orange-950/85 text-orange-400 border border-orange-500/20";
      case "Medium":
        return "bg-slate-900 text-slate-350 border border-slate-800";
      default:
        return "bg-slate-900/60 text-slate-400 border border-slate-950";
    }
  };

  const handleAdminTriage = async (status: IssueStatus) => {
    if (!selectedIssue) return;
    setIsUpdatingState(true);
    try {
      const commentText = adminComment.trim() || `Triage department update: status changed to ${status}`;
      await onUpdateStatus(selectedIssue.id, status, commentText);
      setAdminComment("");
      setIsAdminPanelOpen(false);
    } catch (err) {
      console.error("Failed to update status on incident:", err);
    } finally {
      setIsUpdatingState(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
      {/* LEFT COLUMN: SCROLLABLE LIST & FILTERS (3 Cols) */}
      <div className="lg:col-span-3 flex flex-col gap-4">
        {/* Search & Filters Widget */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl space-y-4">
          {/* Search bar */}
          <div className="relative">
            <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
            <input
              type="text"
              placeholder="Search by keywords, addresses, descriptions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-slate-250 text-sm focus:outline-none focus:border-emerald-500/40 transition placeholder-slate-600"
            />
          </div>

          {/* Category Filter Pills */}
          <div>
            <div className="text-[10px] uppercase font-mono text-slate-500 tracking-wider mb-2 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-slate-500" />
              Category Classification
            </div>
            <div className="flex flex-wrap gap-1.5">
              {CATEGORY_FILTERS.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`text-[11px] px-3 py-1.5 rounded-lg border transition font-mono ${
                    selectedCategory === cat
                      ? "bg-slate-850 text-emerald-400 border-emerald-500/30"
                      : "bg-slate-950 text-slate-400 border-slate-850 hover:bg-slate-900 hover:text-slate-300"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Status Filter Row */}
          <div>
            <div className="text-[10px] uppercase font-mono text-slate-500 tracking-wider mb-2 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              Triage Lifecycle Status
            </div>
            <div className="flex flex-wrap gap-1.5">
              {STATUS_FILTERS.map((stat) => (
                <button
                  key={stat}
                  onClick={() => setSelectedStatus(stat)}
                  className={`text-[11px] px-3.5 py-1.5 rounded-lg border transition font-mono ${
                    selectedStatus === stat
                      ? "bg-slate-850 text-emerald-400 border-emerald-500/30"
                      : "bg-slate-950 text-slate-400 border-slate-850 hover:bg-slate-900"
                  }`}
                >
                  {stat === "All" ? "All Statuses" : stat}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Count Registry line */}
        <div className="text-xs text-slate-500 px-1 font-mono flex justify-between">
          <span>Displaying <strong>{filteredIssues.length}</strong> reports on grid</span>
          {searchTerm && <span>Filter applied</span>}
        </div>

        {/* Incident Scroller List */}
        <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
          {filteredIssues.length === 0 ? (
            <div className="border border-dashed border-slate-800 p-8 rounded-2xl text-center bg-slate-950/40">
              <ShieldAlert className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-450">No reports matched query</p>
              <p className="text-xs text-slate-500 mt-1">Try resetting the filters or file a brand new incident above.</p>
            </div>
          ) : (
            <AnimatePresence mode="popLayout">
              {filteredIssues.map((issue) => {
                const isSelected = issue.id === selectedIssueId;
                const hasVoted = issue.votedUsers.includes(currentUserId);
                const hasVerified = issue.verifiedUsers.includes(currentUserId);

                return (
                  <motion.div
                    key={issue.id}
                    layoutId={`card-${issue.id}`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    onClick={() => onSelectIssue(isSelected ? null : issue.id)}
                    className={`p-4 border rounded-2xl cursor-pointer transition text-left backdrop-blur-sm flex gap-4 relative group ${
                      isSelected
                        ? "bg-slate-850/80 border-emerald-500/30 shadow-lg shadow-emerald-950/10"
                        : "bg-slate-900/60 border-slate-850 hover:border-slate-800 hover:bg-slate-900/80"
                    }`}
                  >
                    {/* Visual Type Indicator Line */}
                    <div className={`w-1 rounded-full shrink-0 ${
                      issue.status === "Resolved"
                        ? "bg-emerald-500"
                        : issue.status === "In Progress"
                        ? "bg-sky-400"
                        : "bg-amber-500"
                    }`} />

                    {/* Left Mini Image thumbnail */}
                    {issue.imageUrl ? (
                      <img
                        src={issue.imageUrl}
                        alt={issue.title}
                        className="w-16 h-16 rounded-xl object-cover border border-slate-800 shrink-0 self-center"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-16 h-16 rounded-xl bg-slate-950 border border-slate-850 shrink-0 flex flex-col items-center justify-center text-slate-600 self-center">
                        <MapPin className="w-5 h-5 text-slate-650" />
                        <span className="text-[8px] font-mono mt-1">No Pic</span>
                      </div>
                    )}

                    {/* Center details */}
                    <div className="flex-1 min-w-0 pr-4">
                      <div className="flex items-center gap-1.5 flex-wrap mb-1.5">
                        <span className={`text-[9px] font-mono px-2 py-0.5 rounded-full font-bold flex items-center gap-1 ${getStatusStyles(issue.status)}`}>
                          {getStatusIcon(issue.status)}
                          {issue.status}
                        </span>
                        <span className={`text-[9px] font-mono px-2 py-0.5 rounded-full font-bold ${getSeverityStyle(issue.severity)}`}>
                          {issue.severity}
                        </span>
                        <span className="text-[9px] font-mono bg-slate-950/50 text-slate-400 px-2 py-0.5 rounded-full border border-slate-850">
                          {issue.category}
                        </span>
                        {issue.aiGenerated && (
                          <span className="text-[9px] font-mono bg-indigo-950 text-indigo-400 px-1.5 py-0.5 rounded-md border border-indigo-500/20 flex items-center gap-0.5" title="Auto-triaged by Gemini">
                            <Sparkles className="w-2.5 h-2.5 text-yellow-350" />
                            AI
                          </span>
                        )}
                      </div>
                      <h4 className="font-bold text-slate-200 text-sm leading-snug truncate group-hover:text-emerald-400 transition">
                        {issue.title}
                      </h4>
                      <p className="text-slate-400 text-xs mt-1 font-sans line-clamp-1 leading-relaxed">
                        {issue.description}
                      </p>
                      <div className="flex justify-between items-center mt-3 text-[10px] font-mono text-slate-500 gap-2">
                        <span className="truncate flex items-center gap-1 max-w-[70%]">
                          <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          {issue.location.address}
                        </span>
                        <span className="shrink-0">
                          {new Date(issue.createdAt).toLocaleDateString([], { month: "short", day: "numeric" })}
                        </span>
                      </div>
                    </div>

                    {/* Right summary indicator panels */}
                    <div className="flex flex-col justify-between items-end border-l border-slate-850 pl-3 shrink-0 py-1">
                      <div className="flex items-center gap-1.5 text-slate-400 p-1" title={`${issue.votes} upvotes`}>
                        <Vote className={`w-3.5 h-3.5 ${hasVoted ? "text-emerald-400" : "text-slate-500"}`} />
                        <span className={`text-xs font-bold font-mono ${hasVoted ? "text-emerald-400" : ""}`}>{issue.votes}</span>
                      </div>
                      <div className="flex items-center gap-1 text-slate-400 p-1" title={`${issue.verifications} crowdsourced verifications`}>
                        <ShieldCheck className={`w-3.5 h-3.5 ${hasVerified ? "text-sky-400" : "text-slate-500"}`} />
                        <span className={`text-[10px] font-mono ${hasVerified ? "text-sky-400" : ""}`}>{issue.verifications}</span>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          )}
        </div>
      </div>

      {/* RIGHT COLUMN: ACTIVE INCIDENT TRIAGE HUB DRAWER (2 Cols) */}
      <div className="lg:col-span-2">
        <AnimatePresence mode="wait">
          {selectedIssue ? (
            <motion.div
              layoutId={`card-${selectedIssue.id}`}
              initial={{ opacity: 0, x: 25 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 25 }}
              className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-2xl space-y-6 text-left relative overflow-hidden h-full flex flex-col justify-between"
            >
              {/* Backglow element */}
              <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/5 rounded-full filter blur-3xl pointer-events-none" />

              <div className="space-y-6">
                {/* Header detail */}
                <div className="flex justify-between items-start border-b border-slate-850 pb-4">
                  <div>
                    <span className="text-[9px] font-mono uppercase bg-slate-950 text-slate-400 px-2.5 py-1 rounded-full border border-slate-850 select-none">
                      Incident: {selectedIssue.id}
                    </span>
                    <h3 className="font-bold text-slate-100 text-base mt-2 leading-snug">{selectedIssue.title}</h3>
                  </div>
                  <button
                    onClick={() => onSelectIssue(null)}
                    className="text-slate-500 hover:text-slate-300 p-1 rounded-full hover:bg-slate-800 transition"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* Evidence Photo */}
                <div className="relative rounded-2xl overflow-hidden bg-slate-950 border border-slate-850 h-40">
                  {selectedIssue.imageUrl ? (
                    <img
                      src={selectedIssue.imageUrl}
                      alt={selectedIssue.title}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center text-slate-500 font-mono text-xs gap-2">
                      <ImageIcon className="w-8 h-8 text-slate-700" />
                      <span>No visual upload submitted.</span>
                    </div>
                  )}
                  {selectedIssue.aiGenerated && (
                    <div className="absolute top-2.5 left-2.5 bg-indigo-950/90 text-indigo-300 text-[9px] font-mono font-bold px-2.5 py-1 rounded-full border border-indigo-500/20 flex items-center gap-1">
                      <Sparkles className="w-2.5 h-2.5 text-yellow-350 animate-pulse" />
                      AI CLASSIFIED
                    </div>
                  )}
                </div>

                {/* Description and location block */}
                <div className="space-y-3">
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 text-xs text-slate-350 leading-relaxed font-sans">
                    <strong>Resident's Description:</strong>
                    <div className="mt-1.5 text-slate-300 whitespace-pre-wrap">{selectedIssue.description}</div>
                  </div>

                  <div className="flex items-start gap-2 text-xs text-slate-300">
                    <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-semibold text-slate-200">Hyperlocal Location</div>
                      <div className="text-slate-400 mt-0.5 font-sans leading-tight">{selectedIssue.location.address}</div>
                      <div className="text-[10px] font-mono text-slate-500 mt-1 select-all">
                        Coords: {selectedIssue.location.lat}, {selectedIssue.location.lng}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Crowdsourced validation and voting block */}
                <div className="p-4 bg-slate-950 border border-slate-850 rounded-2xl space-y-3">
                  <h4 className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Crowdsourced Validation</h4>
                  <div className="grid grid-cols-2 gap-3">
                    {/* Upvote button */}
                    <button
                      onClick={() => onVoteIssue(selectedIssue.id)}
                      className={`px-3 py-2.5 rounded-xl border transition text-xs font-semibold flex items-center justify-center gap-2 ${
                        selectedIssue.votedUsers.includes(currentUserId)
                          ? "bg-emerald-950/60 text-emerald-400 border-emerald-500/30"
                          : "bg-slate-900 text-slate-350 border-slate-850 hover:bg-slate-850 hover:text-slate-200"
                      }`}
                    >
                      <Vote className="w-4 h-4 shrink-0" />
                      <span>{selectedIssue.votedUsers.includes(currentUserId) ? "Upvoted" : "Upvote"} ({selectedIssue.votes})</span>
                    </button>

                    {/* Verify button */}
                    <button
                      onClick={() => onVerifyIssue(selectedIssue.id)}
                      className={`px-3 py-2.5 rounded-xl border transition text-xs font-semibold flex items-center justify-center gap-2 ${
                        selectedIssue.verifiedUsers.includes(currentUserId)
                          ? "bg-sky-950/60 text-sky-400 border-sky-500/30"
                          : "bg-slate-900 text-slate-350 border-slate-850 hover:bg-slate-850 hover:text-slate-200"
                      }`}
                    >
                      <ShieldCheck className="w-4 h-4 shrink-0" />
                      <span>{selectedIssue.verifiedUsers.includes(currentUserId) ? "Verified True" : "Verify Exists"} ({selectedIssue.verifications})</span>
                    </button>
                  </div>
                  <p className="text-[9px] text-slate-500 text-center leading-relaxed font-sans">
                    Public verification prevents falsified reports and elevates repair queue dispatch priority automatically.
                  </p>
                </div>

                {/* Gemini AI Triage Audit */}
                <div className="p-4 bg-purple-950/20 border border-purple-500/10 rounded-2xl space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-purple-400 font-mono">
                    <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                    GEMINI TRIAGE EVALUATION
                  </div>
                  <div className="space-y-2 text-xs leading-normal">
                    <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
                      <div>
                        <span className="text-slate-500 uppercase block">Severity Risk</span>
                        <strong className="text-slate-300 font-bold">{selectedIssue.severity}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 uppercase block">Target Segment</span>
                        <strong className="text-slate-300 font-bold">{selectedIssue.category}</strong>
                      </div>
                    </div>
                    <div className="border-t border-slate-850 pt-2 font-sans">
                      <span className="text-[10px] font-mono text-slate-500 uppercase block">Hazard Impact</span>
                      <p className="text-slate-350 text-[11px] mt-0.5">{selectedIssue.estimatedImpact}</p>
                    </div>
                    <div className="border-t border-slate-850 pt-2 font-sans">
                      <span className="text-[10px] font-mono text-slate-500 uppercase block">Triage Remedial Action</span>
                      <p className="text-slate-350 text-[11px] mt-0.5">{selectedIssue.recommendedAction}</p>
                    </div>
                  </div>
                </div>

                {/* Incident Progress timeline */}
                <div className="space-y-3">
                  <h4 className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Incident Lifecycle Tracker</h4>
                  <div className="space-y-3 pl-2.5">
                    {selectedIssue.history.map((log, index) => {
                      const isLast = index === selectedIssue.history.length - 1;
                      return (
                        <div key={index} className="flex gap-3 text-xs relative">
                          {/* Timeline vertical connector */}
                          {!isLast && (
                            <div className="absolute left-2.5 top-6 bottom-0 w-0.5 bg-slate-800" />
                          )}

                          {/* timeline node icon */}
                          <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 border z-10 ${
                            log.status === "Resolved"
                              ? "bg-emerald-950 text-emerald-400 border-emerald-500/30"
                              : log.status === "In Progress"
                              ? "bg-sky-950 text-sky-400 border-sky-500/30"
                              : "bg-amber-950 text-amber-400 border-amber-500/30"
                          }`}>
                            {log.status === "Resolved" && <CheckCircle className="w-3 h-3" />}
                            {log.status === "In Progress" && <Clock className="w-3 h-3" />}
                            {log.status === "Pending" && <ShieldAlert className="w-3 h-3" />}
                          </div>

                          <div className="flex-1 pb-2">
                            <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono">
                              <span className="font-bold text-slate-300">{log.status} Milestone</span>
                              <span>{new Date(log.updatedAt).toLocaleDateString([], { month: "short", day: "numeric" })} {new Date(log.updatedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                            </div>
                            <p className="text-slate-400 text-xs mt-1 font-sans leading-relaxed">
                              {log.comment}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Administrative/Repair worker simulator panel */}
              <div className="border-t border-slate-850 pt-4 mt-4 space-y-3 shrink-0">
                <div className="flex justify-between items-center">
                  <div className="text-[10px] font-mono text-slate-500 tracking-wider uppercase flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-500" />
                    Town Dispatch Simulator
                  </div>
                  <button
                    onClick={() => setIsAdminPanelOpen(!isAdminPanelOpen)}
                    className="text-[10px] text-purple-400 font-semibold px-2 py-1 bg-purple-950/30 hover:bg-purple-950/60 border border-purple-900/30 rounded-md transition"
                  >
                    {isAdminPanelOpen ? "Hide Triages" : "Triage State Simulator"}
                  </button>
                </div>

                {isAdminPanelOpen && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="p-3.5 bg-slate-950 border border-slate-850 rounded-xl space-y-3"
                  >
                    <div className="text-[10px] font-mono text-slate-400 leading-normal mb-1">
                      Simulate a city engineer or dispatcher making repair progress:
                    </div>
                    <textarea
                      rows={2}
                      placeholder="Enter municipal log comments (e.g. Excavator dispatched...)"
                      value={adminComment}
                      onChange={(e) => setAdminComment(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 focus:outline-none"
                    />
                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <button
                        type="button"
                        disabled={isUpdatingState || selectedIssue.status === "In Progress"}
                        onClick={() => handleAdminTriage("In Progress")}
                        className="px-2 py-1.5 bg-sky-950 text-sky-400 hover:bg-sky-900/40 border border-sky-800/30 rounded-lg text-[10px] font-bold transition flex items-center justify-center gap-1"
                      >
                        <Wrench className="w-3 h-3" />
                        Move to In-Progress
                      </button>
                      <button
                        type="button"
                        disabled={isUpdatingState || selectedIssue.status === "Resolved"}
                        onClick={() => handleAdminTriage("Resolved")}
                        className="px-2 py-1.5 bg-emerald-950 text-emerald-400 hover:bg-emerald-900/40 border border-emerald-800/30 rounded-lg text-[10px] font-bold transition flex items-center justify-center gap-1"
                      >
                        <CheckCircle className="w-3 h-3" />
                        Mark Resolved
                      </button>
                    </div>
                  </motion.div>
                )}
              </div>
            </motion.div>
          ) : (
            <div className="border border-dashed border-slate-800 h-full p-8 rounded-3xl flex flex-col items-center justify-center text-center bg-slate-900/20 backdrop-blur-md">
              <PlusCircle className="w-10 h-10 text-slate-700 mb-3 animate-pulse" />
              <h4 className="font-bold text-slate-300 text-sm">Incident Dossier Center</h4>
              <p className="text-xs text-slate-500 mt-1 max-w-[240px] leading-relaxed mx-auto font-sans">
                Select any incident card or a pin on the vector map to examine full telemetry records, civic timelines, and crowdsourced upvotes.
              </p>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
