import React, { useState, useEffect } from "react";
import { Camera, Sparkles, MapPin, Loader2, Image as ImageIcon, Send, X, AlertTriangle, ShieldCheck, HelpCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { IssueCategory, IssueSeverity } from "../types";

interface ReportFormProps {
  onReportSubmitted: (data: any) => Promise<void>;
  onCancel: () => void;
  selectedCoordinates: { lat: number; lng: number; address: string } | null;
  onEnterReportingMode: () => void;
}

const PRESET_TEST_IMAGES = [
  {
    label: "Pothole Crack",
    url: "https://images.unsplash.com/photo-1515162305285-0293e4767cc2?auto=format&fit=crop&w=600&q=80",
    description: "Deep jagged pothole stretching across the right lane of a busy street."
  },
  {
    label: "Water Pipe Burst",
    url: "https://images.unsplash.com/photo-1542013936693-8848e57412ff?auto=format&fit=crop&w=600&q=80",
    description: "Cold municipal clean water erupting aggressively out of a broken underground joint under a walkway."
  },
  {
    label: "Completely Dark Light",
    url: "https://images.unsplash.com/photo-1509021436665-8f37bc7065be?auto=format&fit=crop&w=600&q=80",
    description: "Overhead light dead above busy pedestrian crossing zone during night."
  },
  {
    label: "Piles of Waste Debris",
    url: "https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&w=600&q=80",
    description: "Bulky matrices, broken construction blocks, and discarded containers dumped on a public forest trail."
  }
];

const REASSURING_AI_MESSAGES = [
  "Initializing server-side Gemini Multi-Modal model...",
  "Encoding image parameters and description headers...",
  "Analyzing physical depth, hazard parameters, and environmental impact...",
  "Selecting optimal department dispatch categorization...",
  "Generating estimated impact reports & remedial city codes...",
  "Polishing recommended dispatch action plans..."
];

export default function ReportForm({
  onReportSubmitted,
  onCancel,
  selectedCoordinates,
  onEnterReportingMode
}: ReportFormProps) {
  // Input fields
  const [description, setDescription] = useState("");
  const [reporterName, setReporterName] = useState("");
  const [reporterEmail, setReporterEmail] = useState("");

  // Result / AI Analyzed States
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<IssueCategory>("Other");
  const [severity, setSeverity] = useState<IssueSeverity>("Medium");
  const [estimatedImpact, setEstimatedImpact] = useState("");
  const [recommendedAction, setRecommendedAction] = useState("");

  // Image states
  const [imageUrl, setImageUrl] = useState("");
  const [imageBase64, setImageBase64] = useState("");
  const [dragActive, setDragActive] = useState(false);

  // States
  const [isAiAnalyzing, setIsAiAnalyzing] = useState(false);
  const [isAiCompleted, setIsAiCompleted] = useState(false);
  const [isAiFallback, setIsAiFallback] = useState(false);
  const [aiMessageIndex, setAiMessageIndex] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState("");

  // Rotate reassuring AI analysis logs
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isAiAnalyzing) {
      interval = setInterval(() => {
        setAiMessageIndex((prev) => (prev + 1) % REASSURING_AI_MESSAGES.length);
      }, 2500);
    } else {
      setAiMessageIndex(0);
    }
    return () => clearInterval(interval);
  }, [isAiAnalyzing]);

  // Handle local image file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith("image/")) {
      setFormError("Selected file must be an image.");
      return;
    }
    setFormError("");

    const reader = new FileReader();
    reader.onload = () => {
      const base64String = reader.result as string;
      setImageUrl(base64String);
      setImageBase64(base64String);
    };
    reader.onerror = () => {
      setFormError("Failed to convert image file.");
    };
    reader.readAsDataURL(file);
  };

  // Drag and drop events
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  // Preset Selection
  const applyPresetImage = (preset: typeof PRESET_TEST_IMAGES[0]) => {
    setImageUrl(preset.url);
    // For Unsplash presets, we'll send the URL. The server can fetch or we'll just send description.
    // In our server, if imageBase64 is empty, it uses text analysis, which still works excellently!
    // To make presets work perfectly with Gemini multimodal: we will fetch them on the client and transform to Base64!
    setIsAiAnalyzing(true);
    setFormError("");
    
    fetch(preset.url)
      .then((res) => res.blob())
      .then((blob) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          setImageBase64(reader.result as string);
          setIsAiAnalyzing(false);
        };
        reader.readAsDataURL(blob);
      })
      .catch((err) => {
        console.error("Failed to base64 preloaded image, using text-only parameter fallback.", err);
        setIsAiAnalyzing(false);
      });

    // Populate standard description if empty
    if (!description) {
      setDescription(preset.description);
    }
  };

  // Trigger server-side Gemini analysis
  const triggerAiAnalysis = async () => {
    if (!description.trim()) {
      setFormError("Please enter a short description first so the AI has context.");
      return;
    }
    setFormError("");
    setIsAiAnalyzing(true);
    setIsAiCompleted(false);

    try {
      const response = await fetch("/api/issues/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          description: description.trim(),
          imageBase64: imageBase64 || null
        })
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || "Failed to analyze reports");
      }

      // Populate form fields with high craftsmanship AI insights
      setTitle(data.title);
      setCategory(data.category);
      setSeverity(data.severity);
      setEstimatedImpact(data.estimatedImpact);
      setRecommendedAction(data.recommendedAction);
      setIsAiFallback(!!data.isFallback);
      setIsAiCompleted(true);
    } catch (err: any) {
      setFormError(`AI triage failed: ${err.message}. Averting to manual filing.`);
    } finally {
      setIsAiAnalyzing(false);
    }
  };

  // Submit complete incident to server
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError("");

    if (!description.trim()) {
      setFormError("Description is required.");
      return;
    }
    if (!selectedCoordinates) {
      setFormError("Geographical pinpointing is mandatory. Click 'Select Location on Map' above.");
      return;
    }

    // Default title if AI wasn't run
    const finalTitle = title.trim() || `Civic issue reported: ${category}`;

    setIsSubmitting(true);
    try {
      await onReportSubmitted({
        title: finalTitle,
        description: description.trim(),
        category,
        location: selectedCoordinates,
        imageUrl: imageUrl || undefined,
        reporterName: reporterName.trim() || "Anonymous Resident",
        reporterEmail: reporterEmail.trim() || "anonymous@civicconnect.net",
        severity,
        estimatedImpact: estimatedImpact.trim() || "Waiting street surveyor audit.",
        recommendedAction: recommendedAction.trim() || "Triage assigned to district depot.",
        aiGenerated: isAiCompleted
      });
    } catch (err: any) {
      setFormError(`Submit failed: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden backdrop-blur-md">
      {/* Background ambient lighting */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/5 rounded-full filter blur-[100px] pointer-events-none" />

      {/* Header */}
      <div className="flex justify-between items-start mb-6">
        <div>
          <span className="text-[10px] uppercase font-mono tracking-widest text-emerald-400 font-bold bg-emerald-950/60 border border-emerald-500/30 px-3 py-1 rounded-full select-none">
            New Citizen Incident Case
          </span>
          <h2 className="text-xl font-bold text-slate-100 mt-2">File Environmental Hazard</h2>
        </div>
        <button
          onClick={onCancel}
          className="text-slate-500 hover:text-slate-300 transition duration-150 p-1.5 rounded-full hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {formError && (
          <div className="p-4 bg-red-950/60 border border-red-500/30 rounded-2xl flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div className="text-xs text-red-300 leading-normal">{formError}</div>
          </div>
        )}

        {/* Reporter Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Reporter Name</label>
            <input
              type="text"
              placeholder="e.g. Rachel Green"
              value={reporterName}
              onChange={(e) => setReporterName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-slate-200 text-sm focus:outline-none focus:border-emerald-500/50 transition"
            />
          </div>
          <div>
            <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Reporter Email (Verified Auth)</label>
            <input
              type="email"
              placeholder="rachel@gmail.com"
              value={reporterEmail}
              onChange={(e) => setReporterEmail(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-slate-200 text-sm focus:outline-none focus:border-emerald-500/50 transition"
            />
          </div>
        </div>

        {/* Description Input */}
        <div>
          <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Visual Description of Hazard *</label>
          <textarea
            required
            rows={3}
            placeholder="Describe the issue, location details, what happened, size, or dynamic risk to surrounding citizens..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-slate-200 text-sm focus:outline-none focus:border-emerald-500/50 transition placeholder-slate-600 resize-none"
          />
        </div>

        {/* Coordinate Selection Block */}
        <div>
          <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Pinpoint Coordinates on Map *</label>
          {selectedCoordinates ? (
            <div className="flex items-center justify-between bg-slate-950 border border-emerald-950/70 p-3.5 rounded-xl">
              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <div className="text-xs font-semibold text-slate-200 leading-tight line-clamp-1">
                    {selectedCoordinates.address}
                  </div>
                  <div className="text-[10px] font-mono text-slate-500 mt-0.5">
                    Latitude: {selectedCoordinates.lat.toFixed(5)} | Longitude: {selectedCoordinates.lng.toFixed(5)}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={onEnterReportingMode}
                className="text-[11px] text-emerald-400 hover:text-emerald-300 font-medium px-2.5 py-1 bg-emerald-950/50 hover:bg-emerald-950 border border-emerald-800/40 rounded-lg transition"
              >
                Change Pin Link
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={onEnterReportingMode}
              className="w-full bg-slate-950 hover:bg-slate-950/60 border border-dashed border-slate-800 hover:border-emerald-500/30 p-4 rounded-xl flex items-center justify-center gap-2 text-xs font-medium text-amber-500/90 transition group"
            >
              <MapPin className="w-4 h-4 group-hover:scale-110 transition shrink-0" />
              Place Pin on Hyperlocal Map Workspace to File Coordinates
            </button>
          )}
        </div>

        {/* Custom Image Upload Workspace */}
        <div>
          <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Upload Incident Evidence</label>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {/* File drop zone */}
            <div
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              className={`md:col-span-3 border-2 border-dashed rounded-xl p-4 transition flex flex-col items-center justify-center text-center cursor-pointer min-h-[140px] ${
                dragActive
                  ? "border-emerald-400 bg-slate-950"
                  : imageUrl
                  ? "border-slate-800 bg-slate-950"
                  : "border-slate-800 bg-slate-950 hover:bg-slate-950/50"
              }`}
            >
              <input
                id="file-upload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileChange}
              />
              {imageUrl ? (
                <div className="relative w-full h-[120px] rounded-lg overflow-hidden border border-slate-800 group">
                  <img src={imageUrl} alt="Uploaded incident" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-2">
                    <label htmlFor="file-upload" className="px-3 py-1.5 bg-slate-900 border border-slate-700 text-xs text-slate-200 rounded-lg cursor-pointer hover:bg-slate-800">
                      Replace Image
                    </label>
                    <button
                      type="button"
                      onClick={() => { setImageUrl(""); setImageBase64(""); }}
                      className="px-3 py-1.5 bg-red-950 border border-red-800/40 text-xs text-red-300 rounded-lg hover:bg-red-900"
                    >
                      Clear
                    </button>
                  </div>
                </div>
              ) : (
                <label htmlFor="file-upload" className="w-full h-full flex flex-col items-center justify-center cursor-pointer py-3">
                  <Camera className="w-7 h-7 text-slate-500 mb-2 group-hover:text-slate-300" />
                  <span className="text-xs font-medium text-slate-400">Drag image here or browse</span>
                  <span className="text-[10px] text-slate-600 mt-1">PNG, JPG, HEIC up to 10MB</span>
                </label>
              )}
            </div>

            {/* preset gallery to help try the app */}
            <div className="md:col-span-2 bg-slate-950 p-3 rounded-xl border border-slate-800 flex flex-col justify-between min-h-[140px]">
              <div className="text-[10px] font-mono uppercase text-slate-500 tracking-wider mb-2 flex items-center gap-1">
                <HelpCircle className="w-3.5 h-3.5" />
                No Asset? Try Dev Presets:
              </div>
              <div className="grid grid-cols-2 gap-2">
                {PRESET_TEST_IMAGES.map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => applyPresetImage(preset)}
                    className="text-left text-[10px] p-1.5 border border-slate-800 hover:border-emerald-500/40 rounded-lg bg-slate-900 overflow-hidden line-clamp-1 transition hover:bg-slate-900/60 truncate"
                  >
                    <div className="font-semibold text-slate-300 max-w-full truncate">{preset.label}</div>
                  </button>
                ))}
              </div>
              <p className="text-[9px] text-slate-500 mt-2 leading-relaxed">
                Applying a preset converts it to Base64 to test Gemini's visual analysis in real-time.
              </p>
            </div>
          </div>
        </div>

        {/* Gemini AI Auto-analyze launcher */}
        <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl relative overflow-hidden flex flex-col gap-3">
          <div className="flex items-start justify-between">
            <div className="flex gap-2.5 items-start">
              <div className="w-7 h-7 bg-indigo-950/60 text-indigo-400 border border-indigo-500/30 rounded-lg flex items-center justify-center shrink-0">
                <Sparkles className="w-4 h-4 animate-pulse" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-200">Gemini-3.5-Flash Auto-Triage</h4>
                <p className="text-[10px] text-slate-500 leading-relaxed mt-0.5">
                  Let Gemini read your picture and text to automatically generate category, precise title, severity, and action logs.
                </p>
              </div>
            </div>
            <button
              type="button"
              disabled={isAiAnalyzing || !description.trim()}
              onClick={triggerAiAnalysis}
              className="text-xs px-3.5 py-2 bg-gradient-to-r from-emerald-500 to-indigo-500 text-white hover:opacity-90 disabled:opacity-40 disabled:pointer-events-none rounded-xl font-semibold transition shrink-0 shadow-lg shadow-indigo-950/20 flex items-center gap-1.5"
            >
              {isAiAnalyzing ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  Triaging...
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                  Analyze with AI
                </>
              )}
            </button>
          </div>

          {/* AI Loader view */}
          {isAiAnalyzing && (
            <div className="mt-2 p-3 bg-indigo-950/30 border border-indigo-900/35 rounded-xl text-center">
              <Loader2 className="w-5 h-5 text-indigo-400 animate-spin mx-auto mb-2" />
              <p className="text-[11px] font-mono text-indigo-300">{REASSURING_AI_MESSAGES[aiMessageIndex]}</p>
            </div>
          )}

          {/* AI Completed Badge */}
          {isAiCompleted && (
            <div className="mt-2 text-[11px] text-emerald-400 bg-emerald-950/40 border border-emerald-900/30 p-2.5 rounded-xl flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                {isAiFallback ? (
                  <strong>Fallback Analysis Engaged!</strong>
                ) : (
                  <strong>Gemini AI Integration Activated!</strong>
                )}{" "}
                Autocompleted form inputs. You can still modify them freely below.
              </span>
            </div>
          )}
        </div>

        {/* Triage Inputs Panel */}
        <div className="p-5 bg-slate-950 border border-slate-800 rounded-2xl space-y-4">
          <h3 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Triage & Classification Directory</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-mono text-slate-500 uppercase tracking-widest mb-1.5">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as IssueCategory)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 text-xs focus:outline-none"
              >
                <option value="Pothole">Pothole</option>
                <option value="Water Leak">Water Leak</option>
                <option value="Streetlight">Streetlight</option>
                <option value="Waste Dumping">Waste Dumping</option>
                <option value="Public Infrastructure">Public Infrastructure</option>
                <option value="Other">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-mono text-slate-500 uppercase tracking-widest mb-1.5">Severity Threat</label>
              <select
                value={severity}
                onChange={(e) => setSeverity(e.target.value as IssueSeverity)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 text-xs focus:outline-none"
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
                <option value="Critical">Critical</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-mono text-slate-500 uppercase tracking-widest mb-1.5">Document Title</label>
            <input
              type="text"
              placeholder="Polished issue title (e.g., Major asphalt blowout on Elm Ave)"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-slate-200 text-xs focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-mono text-slate-500 uppercase tracking-widest mb-1.5">Estimated Hazard/Impact</label>
              <textarea
                rows={2}
                placeholder="Details of potential danger or resource wastage..."
                value={estimatedImpact}
                onChange={(e) => setEstimatedImpact(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-slate-200 text-xs focus:outline-none resize-none placeholder-slate-700"
              />
            </div>
            <div>
              <label className="block text-[10px] font-mono text-slate-500 uppercase tracking-widest mb-1.5">Recommended Municipal Action</label>
              <textarea
                rows={2}
                placeholder="Suggested engineering or cleanup instructions..."
                value={recommendedAction}
                onChange={(e) => setRecommendedAction(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-slate-200 text-xs focus:outline-none resize-none placeholder-slate-700"
              />
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 justify-end pt-3">
          <button
            type="button"
            onClick={onCancel}
            className="text-xs px-5 py-2.5 border border-slate-800 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded-xl transition duration-150 font-medium"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="text-xs px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-slate-950 font-bold rounded-xl transition duration-150 flex items-center justify-center gap-1.5 shrink-0 shadow-lg shadow-emerald-500/10"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                Submitting Report...
              </>
            ) : (
              <>
                <Send className="w-3.5 h-3.5" />
                Submit Incident Report
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
